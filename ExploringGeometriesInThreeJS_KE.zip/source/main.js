import * as THREE from 'three';
import Stats from 'three/examples/jsm/libs/stats.module';
import { GUI } from 'dat.gui';
import { createScene } from './scene.js';
import { createCamera } from './camera';
import { createRenderer } from './renderer.js';
import { addControls } from './orbitControls.js';
import { addLights } from './lights.js';
import { material1, material2, material3, material4, material5} from './materials.js';
import { createMobiusStrip } from './mobius-geometry.js';


//-----INITIALIZE SCENE-----//
let scene = createScene();
const camera = createCamera();
const renderer = createRenderer();
document.body.appendChild(renderer.domElement);
addLights(scene);
const orbitControls = addControls(camera, renderer.domElement);
const stats = Stats();
document.body.appendChild(stats.dom);

//-----HANDLE WINDOW RESIZING-----//
function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
};
window.addEventListener('resize', onWindowResize, false);


//-----SCENE 1: BASIC MESH GEOMETRIES SHOWCASE-----//
const scene1 = createScene();
scene1.background = new THREE.Color(0x000000);
addLights(scene1);
const geometry1 = new THREE.PlaneGeometry(64, 16, 10, 5);
const geometry2 = new THREE.BoxGeometry(5, 5, 5, 10, 10, 10);
const geometry3 = new THREE.SphereGeometry(3, 32, 16, Math.PI / 3, 3 * (Math.PI / 2), 0, Math.PI);
const geometry4 = new THREE.CylinderGeometry(2, 2, 6, 32, 1, false, 0, Math.PI * 2);
const geometry5 = new THREE.TorusGeometry(2, 1, 12, 48, Math.PI * 2);
//Create and add 5 different mesh geometries to scene1
const plane = new THREE.Mesh(geometry1, material5);
plane.rotateX(3 * (Math.PI / 2));
plane.position.set(2, -8, 0);
scene1.add(plane);
const cube = new THREE.Mesh(geometry2, material1);
scene1.add(cube);
const sphere = new THREE.Mesh(geometry3, material2);
sphere.position.set(-8, 0, 0);
sphere.rotation.y = Math.PI / 2;
scene1.add(sphere);
const cylinder = new THREE.Mesh(geometry4, material2);
cylinder.position.set(8, 0, 0);
scene1.add(cylinder);
const torus = new THREE.Mesh(geometry5, material1);
torus.position.set(16, 0, 0);
scene1.add(torus);
//Initialize scene to scene1
scene = scene1;


//-----SCENE 2: CUSTOM MESH GEOMETRY VIA BUFFER GEOMETRY-----//
const scene2 = createScene();
scene2.background = new THREE.Color(0x000000);
addLights(scene2);
//Call function to create mobius strip and add resulting mesh to scene
const mobiusGeom = createMobiusStrip(10, 6, 64);
const mobiusMesh = new THREE.Mesh(mobiusGeom, new THREE.MeshBasicMaterial({ color: 0x00a200, wireframe: true}));
scene2.add(mobiusMesh);
const helper = new THREE.AxesHelper(20);
scene2.add(helper);


//-----SCENE 3: MESH MODIFICATION AND ANIMATION-----//
const scene3 = createScene();
scene3.background = new THREE.Color(0x000000);
addLights(scene3);
//Clone scene1 geometries for modification
const geom2 = geometry2.clone();
const cube2 = new THREE.Mesh(geom2, new THREE.MeshBasicMaterial({color: 0xff0000, wireframe: true,}));
scene3.add(cube2);
const geom3 = geometry3.clone();
const sphere2 = new THREE.Mesh(geom3, material1)
scene3.add(sphere2);


//-----SCENE 4: ADVANCED MATERIALS ON MESH GEOMETRIES-----//
const scene4 = createScene();
scene4.background = new THREE.Color(0x000000);
addLights(scene4);
//Create and add torus mesh with MeshNormal material
const geom5 = geometry5.clone();
const torus2 = new THREE.Mesh(geom5, material4);
torus2.position.set(6, 0, 6);
scene4.add(torus2);
//Create and add torus mesh with MeshDepth material
const torus3 = new THREE.Mesh(geom5, material3);
torus3.position.set(0, 0, 6);
scene4.add(torus3);
//Create and add plane mesh using ShaderMaterial
const textureLoader = new THREE.TextureLoader();
const textureLava = textureLoader.load('./assets/lava.png');
const material6 = new THREE.ShaderMaterial({
    side: THREE.DoubleSide,
    uniforms: {
        time: { value: 0.0 },
        waveFrequency: { value: 1.0},
        waveAmplitude: { value: 1.0},
        textureMap: { value: textureLava }
    },
    vertexShader: `varying vec2 vUv;
                   uniform float time;
                   uniform float waveFrequency;
                   uniform float waveAmplitude;

                   void main() {
                        vUv = uv;

                        vec3 newPos = position;
                        newPos.z += sin(length(position.xy) * waveFrequency + time) * waveAmplitude;

                        gl_Position = projectionMatrix * modelViewMatrix * vec4( newPos, 1.0 );
    }`,
    fragmentShader: `uniform float time;
                     uniform sampler2D textureMap;
                     uniform float waveFrequency;
                     uniform float waveAmplitude;

                     varying vec2 vUv;

                     void main() {
                        vec2 distortedUV = vUv;

                        gl_FragColor = vec4(texture2D(textureMap, distortedUV).xyz, 1.0);
    }`,
});
const geom1 = geometry1.clone();
geom1.scale(1, 2, 1);
const plane2 = new THREE.Mesh(geom1, material6);
scene4.add(plane2);


//-----SCENE SWITCHER-----//
function switchScene() {
    switch (sceneSwitcher.type) {
        case 'scene1':
            scene = scene1;
            break;
        case 'scene2':
            scene = scene2;
            break;
        case 'scene3':
            scene = scene3;
            break;
        case 'scene4':
            scene = scene4;
            break;
    }
};

//-----CREATE GUI-----//
const gui = new GUI();
const sceneSwitcher = {
    type: 'scene1'
};
const sceneFolder = gui.addFolder('Scenes');
sceneFolder.add(sceneSwitcher, 'type', ['scene1', 'scene2', 'scene3', 'scene4']).onChange(switchScene);
const geometryFolder = gui.addFolder('Scene 3: Cube');
const rotationFolder = geometryFolder.addFolder('Rotation');
const scaleFolder = geometryFolder.addFolder('Scale');
rotationFolder.add(cube2.rotation, 'x', 0, Math.PI).name('Rotate X Axis');
rotationFolder.add(cube2.rotation, 'y', 0, Math.PI).name('Rotate Y Axis');
rotationFolder.add(cube2.rotation, 'z', 0, Math.PI).name('Rotate Z Axis');
scaleFolder.add(cube2.scale, 'x', 0, 4).name('Scale X');
scaleFolder.add(cube2.scale, 'y', 0, 4).name('Scale Y');
scaleFolder.add(cube2.scale, 'z', 0, 4).name('Scale Z');


//-----UPDATE SCENE-----//
function animate() {
    requestAnimationFrame(animate);
    material6.uniforms.time.value += 0.05;
    renderer.render(scene, camera);
    orbitControls.update();
    stats.update();
    sphere2.rotation.y += 0.05;
};
animate();