import * as THREE from 'three';

export function createMobiusStrip(radius, width, segments) {
    const mobiusGeometry = new THREE.BufferGeometry();
    const positions = [];
    const indices = [];

    for (let i = 0; i <= segments; i++) {
        const u = i / segments * Math.PI * 4;
        for (let j = 0; j <= segments; j++) {
            const v = (j / segments - 0.5) * width;

            const x = (radius + v * Math.cos(u / 2)) * Math.cos(u);
            const y = (radius + v * Math.cos(u / 2)) * Math.sin(u);
            const z = v * Math.sin(u / 2);

            positions.push(x, y, z);

            if (i < segments && j < segments) {
                const a = i * (segments + 1) +j;
                const b = (i + 1) * (segments + 1) + j;
                const c = (i + 1) * (segments + 1) + (j + 1);
                const d = i * (segments + 1) + (j + 1);

                indices.push(a, b, c);
                indices.push(a, c, d);
            }
        }
    }
    mobiusGeometry.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(positions), 3));
    mobiusGeometry.setIndex(new THREE.Uint16BufferAttribute(new Uint16Array(indices), 1));
    return mobiusGeometry;
}