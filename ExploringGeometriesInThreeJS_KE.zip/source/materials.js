import * as THREE from 'three';

let material = new THREE.MeshBasicMaterial({color: 0xffffff});
const material1 = new THREE.MeshPhongMaterial({
    color: 0x0000ff,
    shininess: 175,
    specular: 0x0000ff
    });
const material2 = new THREE.MeshLambertMaterial({ color: 0xff2400}); 
const material3 = new THREE.MeshDepthMaterial();
const material4 = new THREE.MeshNormalMaterial();
const material5 = new THREE.MeshBasicMaterial({ wireframe: true});


const materialSwitcher = {
        type: 'Phong'
    };

function switchMaterial() {
    switch (materialSwitcher.type){
        case 'Phong':
            material = material1;
            break;
        case 'Lambert':
            material = material2;
            break;
        case 'Depth':
            material = material3;
            break;
        case 'Normal':
            material = material4;
            break;
        case 'Basic':
            material = material5;
            break;
    };
};
export {switchMaterial, materialSwitcher, material1, material2, material3, material4, material5};